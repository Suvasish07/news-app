# news-app
using reactjs  I have made a news app .where you can find rest API call,routing ,calling function,looping through JSON data. and responsive webpages.
